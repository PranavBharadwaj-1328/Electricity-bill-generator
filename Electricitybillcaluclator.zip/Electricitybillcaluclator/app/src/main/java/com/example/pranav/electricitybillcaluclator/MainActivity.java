package com.example.pranav.electricitybillcaluclator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText txt1 = (EditText) findViewById(R.id.txt1);
                EditText txt2 = (EditText) findViewById(R.id.txt2);
                EditText txt3 = (EditText) findViewById(R.id.txt3);
                EditText txt4 = (EditText) findViewById(R.id.txt4);
                EditText txt5 = (EditText) findViewById(R.id.txt5);
                EditText txt6 = (EditText) findViewById(R.id.txt6);
                EditText txt7 = (EditText) findViewById(R.id.txt7);
                EditText txt8 = (EditText) findViewById(R.id.txt8);
                EditText txt9 = (EditText) findViewById(R.id.txt9);
                EditText txt10 = (EditText) findViewById(R.id.txt10);
                EditText txt13 = (EditText) findViewById(R.id.txt13);
                EditText txt14 = (EditText) findViewById(R.id.txt14);
                int n1 = Integer.parseInt(txt1.getText().toString());
                int n2 = Integer.parseInt(txt2.getText().toString());
                int n3 = Integer.parseInt(txt3.getText().toString());
                int n4 = Integer.parseInt(txt4.getText().toString());
                int n5 = Integer.parseInt(txt5.getText().toString());
                int n6 = Integer.parseInt(txt6.getText().toString());
                int n7 = Integer.parseInt(txt7.getText().toString());
                int n8 = Integer.parseInt(txt8.getText().toString());
                int n9 = Integer.parseInt(txt9.getText().toString());
                int n10 = Integer.parseInt(txt10.getText().toString());
                int n11 = n1*n2/10 + n3*n4 + n5*n6*7 + n7*n8*4 + n9*n10/2;
                int n14 = n11*4;
                txt13.setText(n11 + "units");
                txt14.setText(n14 + "Rs");



            }
        });


    }
}
